var searchData=
[
  ['borrarelemento_1',['borrarElemento',['../class_vector___dinamico.html#a040a253f525f881d7e5280ac62073965',1,'Vector_Dinamico']]],
  ['borraringrediente_2',['borrarIngrediente',['../class_ingredientes.html#aaf94717166c3e624390ac5abe136d06a',1,'Ingredientes']]],
  ['borraringredientexnombre_3',['borrarIngredienteXNombre',['../class_ingredientes.html#a7c0b7746dfc25fba382518fe8522a046',1,'Ingredientes']]]
];
