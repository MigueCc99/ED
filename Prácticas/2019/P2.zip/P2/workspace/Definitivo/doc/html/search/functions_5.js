var searchData=
[
  ['operator_3d_52',['operator=',['../class_vector___dinamico.html#a095f58bf99c0eee405111354cfa34e01',1,'Vector_Dinamico']]],
  ['operator_5b_5d_53',['operator[]',['../class_vector___dinamico.html#a93666466d9a2bf8bc4f2a217d5f94bf9',1,'Vector_Dinamico::operator[](const int i)'],['../class_vector___dinamico.html#a3129decf0d63405ced07ded86d5b05f3',1,'Vector_Dinamico::operator[](const int i) const'],['../class_ingredientes.html#ac1a637a4b2fb6e7ce99f59ffea7e5eec',1,'Ingredientes::operator[](const int i)'],['../class_ingredientes.html#a2279d66f71d1fdc39f8560b406d83760',1,'Ingredientes::operator[](const int i) const']]],
  ['ordenapornombre_54',['ordenaPorNombre',['../class_ingredientes.html#a44039882f9e87d1e6fc0a97bf9cac579',1,'Ingredientes']]],
  ['ordenaportipo_55',['ordenaPorTipo',['../class_ingredientes.html#aea7daaebce685d1edacada5fd79034bb',1,'Ingredientes']]]
];
