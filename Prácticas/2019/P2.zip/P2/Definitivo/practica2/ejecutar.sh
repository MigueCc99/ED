#!/bin/bash
echo "Ejecutamos el Programa del Autor: Miguel Ángel Campos"
echo 
./bin/tipos_ingredientes datos/ingredientes.txt Molusco

    