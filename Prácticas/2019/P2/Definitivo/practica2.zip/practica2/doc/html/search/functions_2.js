var searchData=
[
  ['get_58',['get',['../class_ingredientes.html#a97dea81c4db6348691c55e9db5ef3619',1,'Ingredientes']]],
  ['getcalorias_59',['getCalorias',['../class_ingrediente.html#ac5481304477b6f6b6b237a98345cc581',1,'Ingrediente']]],
  ['getestadistica_60',['getEstadistica',['../class_ingredientes.html#a0ee5c7350ec2956cf1f36d8a6e718347',1,'Ingredientes']]],
  ['getfibras_61',['getFibras',['../class_ingrediente.html#a5a64b636d41295ee57dfa22db8cfd413',1,'Ingrediente']]],
  ['getgrasas_62',['getGrasas',['../class_ingrediente.html#a6337fb89787d82ff24cb38d3b3e69f74',1,'Ingrediente']]],
  ['gethidratos_63',['getHidratos',['../class_ingrediente.html#a07418ed4b6db1c3857cf1c7cda1dc92a',1,'Ingrediente']]],
  ['getinformacion_64',['getInformacion',['../class_ingredientes.html#a2f30f251726c114a425e655a07a21d80',1,'Ingredientes']]],
  ['getingrediente_65',['getIngrediente',['../class_ingredientes.html#aeb8017d2e1182f78e3935ca72b766ef8',1,'Ingredientes']]],
  ['getingredientestipo_66',['getIngredientesTipo',['../class_ingredientes.html#ad49a4d1142a214e8c077871efed59c60',1,'Ingredientes']]],
  ['getnombre_67',['getNombre',['../class_ingrediente.html#af487c2d1e772199c006b9e914088653a',1,'Ingrediente']]],
  ['getnumelementos_68',['getNumElementos',['../class_vector___dinamico.html#a568649cf848f2155b4d5eb6ee527bb6c',1,'Vector_Dinamico']]],
  ['getnumingredientes_69',['getNumIngredientes',['../class_ingredientes.html#a485db5688382e8068feb4680caea9a5f',1,'Ingredientes']]],
  ['getproteinas_70',['getProteinas',['../class_ingrediente.html#a8a4685a78101dde5ed338a53567e9346',1,'Ingrediente']]],
  ['gettipo_71',['getTipo',['../class_ingrediente.html#a575ae44e1daae178ca5d6512cadddf93',1,'Ingrediente']]],
  ['gettipos_72',['getTipos',['../class_ingredientes.html#a6f9df794709a67caddd0d89ab38e9ed3',1,'Ingredientes']]]
];
