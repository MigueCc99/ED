var searchData=
[
  ['setcalorias_84',['setCalorias',['../class_ingrediente.html#ad2150e5049aa395abc3f7da9164d5430',1,'Ingrediente']]],
  ['setfibras_85',['setFibras',['../class_ingrediente.html#a35dd8594cd303cf34b3446b3063565ab',1,'Ingrediente']]],
  ['setgrasas_86',['setGrasas',['../class_ingrediente.html#ab0f8de13b5e2d52cfcc490f5d563f601',1,'Ingrediente']]],
  ['sethidratos_87',['setHidratos',['../class_ingrediente.html#abf42e65d643bbdb76070c5a3ed48fbf8',1,'Ingrediente']]],
  ['setnombre_88',['setNombre',['../class_ingrediente.html#af5cbc31813b9aa568f08d769c85f985f',1,'Ingrediente']]],
  ['setproteinas_89',['setProteinas',['../class_ingrediente.html#a7fac9206151fa666bb82dcc25dacb129',1,'Ingrediente']]],
  ['settipo_90',['setTipo',['../class_ingrediente.html#a4afc3ff52fad5910b1ff945d2be237ed',1,'Ingrediente']]],
  ['size_91',['size',['../class_vector___dinamico.html#af4050e799003ac92ab8da36d8bd5bb00',1,'Vector_Dinamico']]]
];
