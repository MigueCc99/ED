var searchData=
[
  ['imprimirportipo_19',['imprimirPorTipo',['../class_ingredientes.html#ab56b335eeb1662c1869d428df28fb035',1,'Ingredientes']]],
  ['ingrediente_20',['Ingrediente',['../class_ingrediente.html',1,'Ingrediente'],['../class_ingrediente.html#ac39e59564451be4c0e12af8ce3d40afb',1,'Ingrediente::Ingrediente()'],['../class_ingrediente.html#ac7fc4a4ac7efac10bc6c583819242d53',1,'Ingrediente::Ingrediente(string nombre, int calorias, int hidratos, int proteinas, int grasas, int fibras, string tipo)'],['../class_ingrediente.html#a49271eb24114ff26846f41696884a8da',1,'Ingrediente::Ingrediente(const Ingrediente &amp;ingrediente)']]],
  ['ingrediente_2eh_21',['ingrediente.h',['../ingrediente_8h.html',1,'']]],
  ['ingredientes_22',['Ingredientes',['../class_ingredientes.html',1,'Ingredientes'],['../class_ingredientes.html#a4599533b7d0530fe6fdd68006b3f0bde',1,'Ingredientes::Ingredientes()']]],
  ['ingredientes_2eh_23',['ingredientes.h',['../ingredientes_8h.html',1,'']]],
  ['insertaringrediente_24',['insertarIngrediente',['../class_ingredientes.html#aa49df6c8d8c48cca8591a620b2d15cc3',1,'Ingredientes']]]
];
