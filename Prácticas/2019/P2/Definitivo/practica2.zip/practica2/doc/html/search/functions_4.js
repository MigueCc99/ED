var searchData=
[
  ['modificaelemento_77',['modificaElemento',['../class_vector___dinamico.html#ab40f55577bcab2af4a0f6a9e7965b05a',1,'Vector_Dinamico']]],
  ['modificaingrediente_78',['modificaIngrediente',['../class_ingredientes.html#a7e56b2666e0c566ba5799d8848669dd4',1,'Ingredientes']]]
];
