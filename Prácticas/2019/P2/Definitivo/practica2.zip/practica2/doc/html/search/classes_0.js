var searchData=
[
  ['ingrediente_48',['Ingrediente',['../class_ingrediente.html',1,'']]],
  ['ingredientes_49',['Ingredientes',['../class_ingredientes.html',1,'']]]
];
