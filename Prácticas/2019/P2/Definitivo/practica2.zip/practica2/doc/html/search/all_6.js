var searchData=
[
  ['rep_20del_20tda_20ingrediente_33',['Rep del TDA Ingrediente',['../rep_ingrediente.html',1,'']]],
  ['rep_20del_20tda_20ingredientes_34',['Rep del TDA Ingredientes',['../rep_ingredientes.html',1,'']]],
  ['rep_20del_20tda_20vector_5fdinamico_35',['Rep del TDA Vector_Dinamico',['../rep_vector__dinamico.html',1,'']]],
  ['resize_36',['resize',['../class_vector___dinamico.html#a1b7bf3f5b5dd748bbb55b8e2cd448c94',1,'Vector_Dinamico']]]
];
