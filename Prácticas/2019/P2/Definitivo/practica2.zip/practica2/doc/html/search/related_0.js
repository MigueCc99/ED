var searchData=
[
  ['operator_3c_3c_94',['operator&lt;&lt;',['../class_ingredientes.html#a11a8ab6e1628b050812fbf57b33265ea',1,'Ingredientes::operator&lt;&lt;()'],['../class_ingrediente.html#af6c4fcbf227d983c422d57f1f3397477',1,'Ingrediente::operator&lt;&lt;()']]],
  ['operator_3e_3e_95',['operator&gt;&gt;',['../class_ingredientes.html#a2f2a26cb7e5d982fcbe248027671937d',1,'Ingredientes::operator&gt;&gt;()'],['../class_ingrediente.html#a79984dcd8864cb7625d3bf29335bf4c3',1,'Ingrediente::operator&gt;&gt;()']]]
];
