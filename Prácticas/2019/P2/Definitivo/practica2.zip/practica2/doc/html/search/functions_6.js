var searchData=
[
  ['resize_83',['resize',['../class_vector___dinamico.html#a1b7bf3f5b5dd748bbb55b8e2cd448c94',1,'Vector_Dinamico']]]
];
