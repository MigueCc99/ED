var searchData=
[
  ['rep_20del_20tda_20ingredientes_23',['Rep del TDA Ingredientes',['../rep_ingredientes.html',1,'']]],
  ['rep_20del_20tda_20vector_5fdinamico_24',['Rep del TDA Vector_Dinamico',['../rep_vector__dinamico.html',1,'']]],
  ['resize_25',['resize',['../class_vector___dinamico.html#a1b7bf3f5b5dd748bbb55b8e2cd448c94',1,'Vector_Dinamico']]]
];
