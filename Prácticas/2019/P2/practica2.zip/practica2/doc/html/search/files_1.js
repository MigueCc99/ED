var searchData=
[
  ['vector_5fdinamico_2eh_35',['vector_dinamico.h',['../vector__dinamico_8h.html',1,'']]]
];
