var searchData=
[
  ['imprimirportipo_47',['imprimirPorTipo',['../class_ingredientes.html#ab56b335eeb1662c1869d428df28fb035',1,'Ingredientes']]],
  ['ingredientes_48',['Ingredientes',['../class_ingredientes.html#a4599533b7d0530fe6fdd68006b3f0bde',1,'Ingredientes']]],
  ['insertaringrediente_49',['insertarIngrediente',['../class_ingredientes.html#aa49df6c8d8c48cca8591a620b2d15cc3',1,'Ingredientes']]]
];
