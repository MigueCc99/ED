#ifndef _INGREDIENTES_H_
#define _INGREDIENTES_H_

//#include <string>
#include "vector_dinamico.h"
#include "ingrediente.h"

class Ingredientes{
private:
    /**
 *  @page repIngrediente Rep del TDA Ingredientes
 *  @section invIngredientes Invariante de la representación
 *  El invariante es \e numIngredientes >0
 * *  @section faIngrediente Función de abstracción
 *  Un objeto válido @e rep del TDA Ingrediente representa al valor
 *  {Nombre, Calorias, Hidratos, Proteinas, Grasas, Fibras, Tipo}
 **/

    Vector_Dinamico<Ingrediente> datos;

public:
    Ingredientes();
    void insertarIngrediente(const Ingrediente &ingrediente);
    void borrarIngrediente(const int nroIngrediente);
    void borrarIngredienteXNombre(const string &nombre);
    void modificaIngrediente(const int i, const Ingrediente &ingrediente);
    Ingrediente getIngrediente(const int i);
    Ingrediente get(const string &nombre);
    const int getNumIngredientes() const;
    string getInformacion(const string nombre);
    Vector_Dinamico<string> getTipos();
    Ingredientes getIngredientesTipo(const string tipo);
    Ingrediente &operator[](const int i);
    const Ingrediente &operator[](const int i) const;
    void ordenaPorNombre();
    Ingredientes ordenaPorTipo();
    void imprimirPorTipo(ostream &os);

    friend ostream &operator<<(ostream &os, const Ingredientes &ingredientes);
    friend istream &operator>>(istream &is, Ingredientes &ingredientes);
};

#endif