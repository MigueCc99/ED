#ifndef _VECTOR_DINAMICO_H_
#define _VECTOR_DINAMICO_H_

template <class T>
class Vector_Dinamico{
private:
    /**
 *  @page repVector_Dinamico Rep del TDA Vector_Dinamico
 *  @section invVector_Dinamico Invariante de la representación
 *  El invariante es \e rep.nelementos >= 0
 *                   \e rep.datos apunta a una zona de memoria con capacidad para albergar nelementos de tipo T
 * *  @section faVector_Dinamico Función de abstracción
 *  Un objeto válido @e rep del TDA Vector_Dinamico representa al valor
 *  {rep.datos[0], rep.datos[1], ... , rep.datos[nelementos-1}
 **/
    T *datos;
    int nelementos;
    int reservados;

public:

Vector_Dinamico();
Vector_Dinamico(int n);
Vector_Dinamico(const Vector_Dinamico &original);
~Vector_Dinamico();
int size() const;
int getNumElementos() const;
void resize(int n);
T &operator[](const int i);
const T &operator[](const int i) const;
bool operator==(const T &elemento);
Vector_Dinamico &operator=(const Vector_Dinamico &original);
void aniadeElemento(const T &elemento);
void borrarElemento(const int posicion);
void modificaElemento(const int posicion, const T &elemento);

};

#include "vector_dinamico.tpp"

#endif 